package com.study.free.vo;

public class TempVO {
	private String tempCol1;
	private String tempCol2;
	private String tempCol3;
	public String getTempCol1() {
		return tempCol1;
	}
	public void setTempCol1(String tempCol1) {
		this.tempCol1 = tempCol1;
	}
	public String getTempCol2() {
		return tempCol2;
	}
	public void setTempCol2(String tempCol2) {
		this.tempCol2 = tempCol2;
	}
	public String getTempCol3() {
		return tempCol3;
	}
	public void setTempCol3(String tempCol3) {
		this.tempCol3 = tempCol3;
	}
	
	
}
