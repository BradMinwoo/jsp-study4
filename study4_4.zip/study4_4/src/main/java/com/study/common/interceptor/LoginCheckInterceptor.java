package com.study.common.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.study.login.vo.UserVO;

public class LoginCheckInterceptor extends HandlerInterceptorAdapter  {
	// RequestMappling 가기전, 후에 여러가지 공통된 기능을 실행하는게 인터셉터
	
	// 메소드이름 : 가기전에 실행
	// retrun type boolean : true 일대 RequestMapping메소드 가냥 못가냐? 정답은 간다
	// 로그인이 안되어있으면 true false
	// 로그인이 안되어있다는 어떻게 판단?? session
	// 여기로 오는 request는 애초에 /mypage/* 에 대한 request
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
		HttpSession session = request.getSession();
		UserVO user = (UserVO)session.getAttribute("USER_INFO");
		if(user==null) {
			//로그인 x
			response.sendRedirect(request.getContextPath()+"/login/login.wow");
			return false;
		}
		//로그인
		return true;
	}
	

}
